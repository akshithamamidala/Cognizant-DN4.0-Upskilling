public class ReverseEngineer {
public void sayHello() {
System.out.println("Hello from Example!");
}
public static void main(String[] args) {
new Example().sayHello();
}
}

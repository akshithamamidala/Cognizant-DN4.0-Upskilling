public class DataType{
public static void main(String[] args){
int age = 16;
float temperature = 42f;
double pi = 3.1415;
char grade = 'A';
boolean isJavaFun = true;
System.out.println("Integer : " + age);
System.out.println("Float : " + temperature);
System.out.println("Double : " + pi);
System.out.println("Character : " + grade);
System.out.println("Boolean : " + isJavaFun);
}
}

public class TypeCasting{
public static void main(String[] args){
double d = 9.75;
int intValue = (int) d;
System.out.println("Double to int:");
System.out.println("Original double value: " + d);
System.out.println("After casting to int: " + intValue);
int n = 42;
double convertedDouble = n;
System.out.println("\nInt to double:");
System.out.println("Original int value: " + n);
System.out.println("After casting to double: " + convertedDouble);
}
}
